# mosdex-python

Package is in `mosdex-python/mosdex`

A sailco example is in the `samples` directory.

The experimental version of MOSDEX Schema and some example files are in `mosdex-python/data`

PDFs of the output are in `mosdex-python/data`